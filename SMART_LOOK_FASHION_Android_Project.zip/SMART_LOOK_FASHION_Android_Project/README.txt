SMART LOOK FASHION — Android Studio project

This project wraps the existing SMART LOOK FASHION HTML app in an Android WebView.
It is an Android app source project, not a compiled APK yet.

BUILD AN APK
1. On a Windows, Mac, or Linux computer, install Android Studio.
2. Extract this ZIP.
3. In Android Studio choose Open, then select the extracted SMART_LOOK_FASHION_Android_Project folder.
4. Allow Android Studio to sync/download the Android Gradle plugin and SDK components.
5. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
6. When the build finishes, use the notification's locate link. The APK is normally at:
   app/build/outputs/apk/debug/app-debug.apk
7. Copy that APK to your Android phone, open it, and allow installation from that source if Android asks.

APP DATA NOTE
The app uses the existing HTML application and WebView local storage. Keep the same installed app when updating so Android retains the app's private data where possible. Do not uninstall an existing app before backing up its data.

IMPORTANT
The APK has not been compiled or tested on a physical Android device in this environment. Test customer saving, logo display, invoices, monthly reports, printing/PDF export, and backup before relying on it for business records.
